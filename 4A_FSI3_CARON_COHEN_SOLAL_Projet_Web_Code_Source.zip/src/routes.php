<?php
// Routes

//----------------- Affiche la page d'accueil ------------------\\
$app->get('/', function ($request, $response, $args) {
    
    return $this->renderer->render($response, 'accueil.phtml', $args);
});

//----------------- Créer un contact et envoi les infos à la base de donnée------------------\\
$app->post('/formulaire', function ($request, $response, $args) {
$this->db;
	
	$nom = strip_tags($_POST['nom']); // recupere le nom du formulaire
	$prenom = strip_tags($_POST['prenom']);  // recupere le prenom du formulaire
    $promo = strip_tags($_POST['promo']);  // recupere la promo du formulaire
    $classe = strip_tags($_POST['classe']);  // recupere la classe du formulaire
    $sousgroupe = strip_tags($_POST['sousgroupe']);  // recupere le sous groupe du formulaire
    $groupeanglais = strip_tags($_POST['groupeanglais']);  // recupere le groupe d'angais du formulaire
    $groupelv2 = strip_tags($_POST['groupelv2']);  // recupere le groupe LV2 du formulaire
    $telephone = strip_tags($_POST['telephone']);  // recupere le telephone du formulaire
    $mail = strip_tags($_POST['mail']);  // recupere le mail du formulaire
    
    
    //var_dump($_POST);    //test le type de variable
    
    if($nom=="" || $prenom=="" || $promo=="" || $classe=="" || $sousgroupe=="" || $groupeanglais=="" || $telephone=="" || $mail=="")
	{	
		echo "Vous avez oublié de remplir un champ";
	}
	else
	{
		$contact = new contact();
		$contact->name = $nom;
		$contact->firstname = $prenom;
        $contact->promotion = $promo;
        $contact->group = $classe;
        $contact->ssgroup = $sousgroupe;
        $contact->englishgroup = $groupeanglais;
        $contact->lv2group = $groupelv2;
        $contact->phone = $telephone;
        $contact->email = $mail;
		$contact->save();
	}
   

return $response->withStatus(302)->withHeader('Location', '/affichage');
});
$app->get('/formulaire', function ($request, $response, $args) {
    return $response->withStatus(302)->withHeader('Location', '/affichage');
});


//----------------- Affiche tous les contacts ------------------\\

$app->get('/affichage', function ($request, $response, $args) {
    
    $this->db;
    $contacts=contact::all();
     return $this->renderer->render($response, 'afficher_les_contacts.phtml', ['contact'=>$contacts]);
});


//----------------- Affiche le formulaire ------------------\\

$app->get('/form', function ($request, $response, $args) {
    
    
     return $this->renderer->render($response, 'ajouter_contact.phtml', $args);
});

//----------------- Affiche un seul contact (selectionné) ------------------\\

$app->get('/zoom[{id}]', function ($request, $response, $args) {
    
    $this->db;
    $contact=contact::find((int)$args['id']);
    
     return $this->renderer->render($response, 'afficher_un_contact.phtml', ['contact'=>$contact]);
});

//----------------- Affiche un nouveau formulaire avec les informations du contact selectionné------------------\\

$app->get('/update[{id}]', function ($request, $response, $args) {
    
    $this->db;
    $contact=contact::find((int)$args['id']);
    
     return $this->renderer->render($response, 'modifier_un_contact.phtml', ['contact'=>$contact]);
});


//----------------- Supprime un contact ------------------\\

$app->get('/delete[{id}]', function ($request, $response, $args) {
    
    $this->db;
    $contact= contact::where('id',$args['id'])->delete();
    $contact= contact::all();    
    
    return $this->renderer->render($response, 'afficher_les_contacts.phtml', ['contact'=>$contact]);
});


//------- Install et créer la bdd avec les tables -----------\\
 
$app->get('/install', function ($request, $response, $args) {

$this->db;

    $capsule = new \Illuminate\Database\Capsule\Manager;
	$capsule::schema()->dropIfExists('contacts');
    $capsule::schema()->create('contacts', function (\Illuminate\Database\Schema\Blueprint $table) {
       $table->increments('id');
        $table->string('name')->default("");
		$table->string('firstname')->default("");
        $table->string('promotion')->default("");
        $table->string('group')->default("");
        $table->string('ssgroup')->default("");
        $table->string('englishgroup')->default("");
        $table->string('lv2group')->default("");
        $table->string('phone')->default("");
        $table->string('email')->default("");
        // Include created_at and updated_at
       $table->timestamps();
   });
   return $this->renderer->render($response, 'accueil.phtml', $args);
});