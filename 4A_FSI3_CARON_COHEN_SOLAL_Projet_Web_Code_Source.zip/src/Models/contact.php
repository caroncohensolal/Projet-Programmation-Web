<?php
//User Model
use Illuminate\Database\Eloquent\Model as Eloquent;
    
class contact extends Eloquent {
   private $id;
   private $name;

   function is_id() 
   {
       return $this->id;
   }

   function what_name() 
   {
       return $this->name;
   }

    public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getName(){
		return $this->name;
	}

	public function setName($name){
		$this->name = $name;
	}
}